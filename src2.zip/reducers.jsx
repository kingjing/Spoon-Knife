import { combineReducers } from 'redux';
import { ADD_TODO } from './actions'
const initialState = {
    visibilityFilter: [],
    todos: []
};

function todoApp(state = initialState, action) {
    // 这里暂不处理任何 action，
    // 仅返回传入的 state。
    return state;
}
export default todoApp;