import React, {Component, PropTypes} from 'react';
import Head from '../components/Head';
import GoodsList from '../components/GoodsList';
import HeadCss from './HeadCss';
import CartCss from './CartCss'

class App extends Component {
  constructor() {
      super();
  }
  render(){
    return(
        <div>
          <Head />
          <GoodsList />
        </div>
    )
  }
}
export default App;