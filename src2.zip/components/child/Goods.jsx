import React, {Component, PropTypes} from 'react';

class Goods extends Component {
    constructor() {
        super();
    }
    render(){
        return(
            <div className="cartPInfo"  id="p-main-0-38232-18656">
                <div className="clearit">
                    <div className="pItem pCheckbox">
                        <input name="cart_list"  className="chk_p chk_p_main" defaultValue="main-0-38232-18656" type="checkbox" defaultChecked />
                    </div>
                    <div className="pItem pGoods">
                        <div className="clearfix">
                            <div className="cart_pimg">
                                <a target="_blank" title="小广州奶茶" href="http://www.t.com/html/products/19/1500018656.html">
                                    <img width="62" height="62" src="http://i.t.com/html/images/330pic.jpg"/>
                                </a>
                            </div>
                            <div className="cart_pname">
                                <div>
                                    <a target="_blank" href="http://www.t.com/html/products/19/1500018656.html" title="小广州奶茶">小广州奶茶</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="pItem spree_sm03 spree_p10">
                        <span>
                            <strong>¥30</strong>
                        </span>
                    </div>
                    <div className="pItem pPromotion">&nbsp;</div>
                    <div className="pItem pQuantity">
                        <div className="cartAmount">
                            <a href="javascript:void(0);" className="cartCountBtn numberCtrl down" belong="main" cid="main-0-38232-18656" canselect="1">-</a>
                            <input type="text"  defaultValue="1" className="amount pAmount" id="main-0-38232-18656-amount" name="amount" cid="main-0-38232-18656" canselect="1" stock="-10" />
                            <input type="hidden" defaultValue="1" id="main-0-38232-18656-amountHidden" />
                            <a href="javascript:void(0);" className="cartCountBtn numberCtrl up" belong="main" cid="main-0-38232-18656" canselect="1" stock="-10">+</a>
                        </div>
                        <div className="pGift-tips" style={{display:'none'}} id="tips-main-0-38232-18656">
                            <span className="pGift-tips-up"></span>
                            <span className="pGift-tips-words" id="tips-msg-main-0-38232-18656">
                                活动库存告急，继续购买将以原价结算哦！
                            </span>
                        </div>
                    </div>
                    <div className="pItem pWeight">0.2kg<br/></div>
                    <div className="pItem pSubtotal">
                        ¥
                        <span id="total_price">30</span>
                    </div>
                    <div className="pItem pInventory">现货</div>
                    <div className="pItem pOperator">
                        <div style={{display:'none'}} className="getfavok" id="follow-18656-38232">商品收藏成功</div>
                        <a id="cartDel" className="follow" pid="18656" cid="38232" href="javascript:void(0)">收藏</a>&nbsp;&nbsp;
                        <a id="cartDel" className="remove" cid="main-0-38232-18656" href="javascript:void(0)">删除</a>
                    </div>
                </div>
            </div>
      )
    }
  }
  export default Goods;