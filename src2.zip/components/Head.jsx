import React, {Component, PropTypes} from 'react';

class Head extends Component {
  constructor() {
      super();
  }
  render () {
    var h1Style = {
      textIndent : '-9999px'
    };
    var iUrl = "http://i.t.com/";
    return(
      <div id="header">
        <div className="header_inner">
            <div className="logo">
                <a href=""></a>
                <a href="" className="logoright" title="顺丰优选">
                    <h1 style={h1Style}>顺丰优选</h1>
                    {this.props.item}
                </a>
                <div className="logo-text">
                  <img src={iUrl + 'html/images/logo_word.jpg'} />
                </div>
            </div>
            <div style={{float:'right', width:'650px', paddingTop:'30px'}}> <img src={iUrl + 'com/images/step_01.jpg'} /></div>
        </div>
    </div>
    )
  }
}
export default Head;