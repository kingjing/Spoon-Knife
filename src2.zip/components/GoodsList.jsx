import React, {Component, PropTypes} from 'react';
import Goods from './child/Goods';

class GoodsList extends Component {
  constructor() {
      super();
  }
  render(){
    return(
        <div className="cartMain" id="cartMain">
            <div className="cartThead">
                <div className="tCol tCheckbox">
                    <input name="acart_list_check" id="Zall" type="checkbox" className="selectAll"/>
                    全选
                </div>
                <div className="tCol tGoods">商品</div>
                <div className="tCol tPrice">单价</div>
                <div className="tCol tPromotion">优惠</div>
                <div className="tCol tQuantity">数量</div>
                <div className="tCol tWeight">重量(含包装)</div>
                <div className="tCol tSubtotal">小计</div>
                <div className="tCol tInventory">库存状态</div>
                <div className="tCol tOperator">操作</div>
            </div>
            <div id="prodList" style={{minHeight: '50px'}}>
                <div className="cartTbody">
                    <div className="cartList youxuan" id="all_putong">
                        <div style={{margin:'20px',textAlign:'center',display:'none'}} id="danjianload"></div>
                        <div className="cartColumnhd">
                            <div className="cartCheckbox">
                                <input name="cart_list_yx" id="Zpu" type="checkbox" className="selectAll ptm" />优选商品
                            </div>
                        </div>
                        <div className="cartItem">
                            {/*// 商品列表*/}
                            <Goods></Goods>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
  }
}
export default GoodsList;