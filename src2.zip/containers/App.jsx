import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { addTodo } from '../actions';
import Head from '../components/Head';
import GoodsList from '../components/GoodsList';
import HeadCss from '../components/HeadCss';
import CartCss from '../components/CartCss';

class App extends Component {
  constructor() {
      super();
  }
  render(){
      let text = 'aaaaaaaaa';
    return(
        <div>
            <div>
                {this.props.errorMessage}
            </div>
          <Head item={this.props.errorMessage}/>
          <GoodsList />
        </div>
    )
  }
}

const mapStateToProps = (state, ownProps) => ({
    errorMessage: 'XXXXAAAAAA'
  })
export default connect(mapStateToProps)(App);