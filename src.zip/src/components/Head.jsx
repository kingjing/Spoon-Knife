import React, {Component, PropTypes} from 'react';

class Head extends Component {
  constructor() {
      super();
  }
  render(){
    return(
        <div>
          <h1>lesson 1 </h1>
          <p>page1</p>
        </div>
    )
  }
}
export default Head;