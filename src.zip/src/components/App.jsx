import React, {Component, PropTypes} from 'react';
import Head from './Head.jsx';

class App extends Component {
  constructor() {
      super();
  }
  render(){
    return(
        <div>
          <Head></Head>
          <p>page1</p>
        </div>
    )
  }
}
export default App;